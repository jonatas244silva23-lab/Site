/* ============================================================
   ONYX — RENDER
   Funções puras: recebem dados, devolvem HTML em string.
   ============================================================ */

function numberFmt(n) {
  return n.toLocaleString("pt-BR");
}

function renderStatCard(stat) {
  const positive = stat.delta > 0;
  const neutral = stat.delta === 0;
  const deltaHtml = neutral
    ? ""
    : `<span class="stat-delta ${positive ? "positive" : "negative"}">
         ${positive ? "↗" : "↘"} ${Math.abs(stat.delta)}%
       </span>`;

  return `
    <div class="stat-card">
      <div class="stat-top">
        <div class="stat-icon">${stat.icon}</div>
        ${deltaHtml}
      </div>
      <p class="stat-value mono">${numberFmt(stat.value)}</p>
      <p class="stat-label">${stat.label}</p>
    </div>
  `;
}

function renderBotCard(bot) {
  return `
    <div class="bot-card">
      <div class="bot-left">
        <div class="bot-icon">◆</div>
        <div>
          <div class="bot-name-row">
            <span class="bot-name">${bot.name}</span>
            <span class="status-dot ${bot.status}"></span>
          </div>
          <p class="bot-number mono">${bot.number}</p>
        </div>
      </div>
      <div class="bot-right">
        <p class="bot-event">${bot.lastEvent}</p>
        <p class="bot-uptime mono">uptime ${bot.uptime}</p>
      </div>
    </div>
  `;
}

function renderActivityRow(item) {
  const badgeText = item.kind === "credit" ? "R$" : item.kind === "bot" ? "◆" : "</>";
  return `
    <div class="activity-row">
      <div class="activity-left">
        <span class="activity-badge ${item.kind}">${badgeText}</span>
        <div>
          <p class="activity-label">${item.label}</p>
          <p class="activity-detail">${item.detail}</p>
        </div>
      </div>
      <span class="activity-time mono">${item.time}</span>
    </div>
  `;
}

function renderSkeletonBlock(height) {
  return `<div class="skeleton-block" style="height:${height}px;width:100%;"></div>`;
}
