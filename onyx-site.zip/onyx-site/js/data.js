/* ============================================================
   ONYX — DATA LAYER
   Tudo aqui simula respostas de API. Pra plugar de verdade,
   troque o corpo de cada função fetchXxx() por uma chamada
   fetch() real, mantendo o mesmo formato de retorno (Promise).
   ============================================================ */

const MOCK_ACCOUNT = {
  name: "Jonh-Rest",
  plan: "Pro",
  credits: 1450,
};

const MOCK_STATS = [
  { id: "credits", label: "Créditos", value: 1450, delta: 12.4, icon: "●" },
  { id: "today", label: "Requisições hoje", value: 312, delta: 8.1, icon: "↗" },
  { id: "month", label: "Requisições no mês", value: 9840, delta: -3.2, icon: "▤" },
  { id: "bots", label: "Bots ativos", value: 3, delta: 0, icon: "◆" },
];

const MOCK_BOTS = [
  {
    id: "bot-1",
    name: "Atendimento Loja",
    number: "+55 93 9142-3261",
    status: "online",
    uptime: "14d 6h",
    lastEvent: "Mensagem recebida há 2 min",
  },
  {
    id: "bot-2",
    name: "Suporte Técnico",
    number: "+55 93 9981-0044",
    status: "online",
    uptime: "6d 21h",
    lastEvent: "Comando executado há 9 min",
  },
  {
    id: "bot-3",
    name: "Disparo Promo",
    number: "+55 93 9220-7788",
    status: "offline",
    uptime: "—",
    lastEvent: "Desconectado há 3h",
  },
];

const MOCK_ACTIVITY = [
  { id: 1, label: "Recarga de créditos", detail: "+220 créditos via PIX", time: "Há 18 min", kind: "credit" },
  { id: 2, label: "Bot conectado", detail: "Atendimento Loja", time: "Há 1h", kind: "bot" },
  { id: 3, label: "Endpoint chamado", detail: "/v1/send-message", time: "Há 2h", kind: "api" },
  { id: 4, label: "Bot desconectado", detail: "Disparo Promo", time: "Há 3h", kind: "bot" },
  { id: 5, label: "Recarga de créditos", detail: "+550 créditos via PIX", time: "Ontem", kind: "credit" },
];

function fetchAccount() {
  return new Promise((resolve) => setTimeout(() => resolve(MOCK_ACCOUNT), 200));
}

function fetchStats() {
  return new Promise((resolve) => setTimeout(() => resolve(MOCK_STATS), 320));
}

function fetchBots() {
  return new Promise((resolve) => setTimeout(() => resolve(MOCK_BOTS), 280));
}

function fetchActivity() {
  return new Promise((resolve) => setTimeout(() => resolve(MOCK_ACTIVITY), 380));
}
