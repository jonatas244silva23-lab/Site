/* ============================================================
   ONYX — APP
   Controlador principal: busca os dados, popula o DOM e
   liga as interações (sidebar, navegação).
   ============================================================ */

document.addEventListener("DOMContentLoaded", () => {
  initSidebarToggle();
  initNavigation();
  loadAccount();
  loadStats();
  loadBots();
  loadActivity();
});

/* -------- Sidebar mobile -------- */
function initSidebarToggle() {
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("sidebar-overlay");
  const openBtn = document.getElementById("sidebar-open");
  const closeBtn = document.getElementById("sidebar-close");

  function open() {
    sidebar.classList.add("open");
    overlay.classList.add("open");
  }
  function close() {
    sidebar.classList.remove("open");
    overlay.classList.remove("open");
  }

  openBtn.addEventListener("click", open);
  closeBtn.addEventListener("click", close);
  overlay.addEventListener("click", close);
}

/* -------- Navegação lateral -------- */
function initNavigation() {
  const items = document.querySelectorAll(".nav-item");
  items.forEach((item) => {
    item.addEventListener("click", () => {
      items.forEach((i) => i.classList.remove("active"));
      item.classList.add("active");
      // Aqui é onde, futuramente, trocamos a "página" exibida
      // de acordo com item.dataset.target (overview, bots, credits...).
    });
  });
}

/* -------- Conta / topbar -------- */
function loadAccount() {
  fetchAccount().then((account) => {
    const creditsEl = document.getElementById("credits-value");
    const nameEl = document.getElementById("user-name");
    const avatarEl = document.getElementById("user-avatar");
    const greetingEl = document.getElementById("greeting");

    creditsEl.textContent = numberFmt(account.credits);
    creditsEl.classList.remove("skeleton-text");

    nameEl.textContent = account.name;
    avatarEl.textContent = account.name.charAt(0);

    greetingEl.textContent = `Olá, ${account.name.split(" ")[0]}`;
  });
}

/* -------- Subtítulo (depende de bots, então roda separado) -------- */
function updateSubgreeting(bots) {
  const subEl = document.getElementById("subgreeting");
  const onlineCount = bots.filter((b) => b.status === "online").length;
  const dateStr = new Date().toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
  });
  const botWord = onlineCount === 1 ? "bot online" : "bots online";
  subEl.textContent = `${onlineCount} ${botWord} agora · ${dateStr}`;
}

/* -------- Stats -------- */
function loadStats() {
  const grid = document.getElementById("stats-grid");
  grid.innerHTML = Array.from({ length: 4 })
    .map(() => renderSkeletonBlock(112))
    .join("");

  fetchStats().then((stats) => {
    grid.innerHTML = stats.map(renderStatCard).join("");
  });
}

/* -------- Bots -------- */
function loadBots() {
  const list = document.getElementById("bots-list");
  list.innerHTML = Array.from({ length: 3 })
    .map(() => renderSkeletonBlock(68))
    .join("");

  fetchBots().then((bots) => {
    list.innerHTML = bots.map(renderBotCard).join("");
    updateSubgreeting(bots);
  });
}

/* -------- Atividade -------- */
function loadActivity() {
  const list = document.getElementById("activity-list");
  list.innerHTML = renderSkeletonBlock(180);

  fetchActivity().then((activity) => {
    list.innerHTML = activity.map(renderActivityRow).join("");
  });
}
